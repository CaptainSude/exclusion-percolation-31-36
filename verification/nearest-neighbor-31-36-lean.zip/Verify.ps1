param(
    [string]$LakePath = 'lake',
    [string]$PackageOverrides = ''
)

$ErrorActionPreference = 'Stop'
$taskOldLocation = Get-Location
try {
    Set-Location -LiteralPath $PSScriptRoot
    $taskLakeArgs = @()
    if ($PackageOverrides) {
        $taskOverridePath = (Resolve-Path -LiteralPath $PackageOverrides).Path
        $taskLakeArgs += "--packages=$taskOverridePath"
    }

    $taskVersion = & $LakePath @taskLakeArgs env lean --version 2>&1
    if ($LASTEXITCODE -ne 0) { throw 'Cannot run the pinned Lean toolchain.' }
    if (($taskVersion -join "`n") -notmatch 'Lean \(version 4\.34\.1[,\)]') {
        throw "Expected Lean 4.34.1. Found: $taskVersion"
    }

    New-Item -ItemType Directory -Path verification -Force | Out-Null
    function Get-TaskSourceHashes {
        $taskSources = @(
            Get-ChildItem -LiteralPath $PSScriptRoot -Filter '*.lean' -File
            Get-ChildItem -LiteralPath (Join-Path $PSScriptRoot 'ExceptionalTimes') -Filter '*.lean' -File
        ) | Sort-Object FullName
        foreach ($taskSource in $taskSources) {
            [ordered]@{
                path = $taskSource.FullName.Substring($PSScriptRoot.Length + 1).Replace('\', '/')
                sha256 = (Get-FileHash -LiteralPath $taskSource.FullName -Algorithm SHA256).Hash.ToLowerInvariant()
            }
        }
    }
    $taskBeforeHashes = @(Get-TaskSourceHashes)
    $taskAuditText = Get-Content -LiteralPath (Join-Path $PSScriptRoot 'ExceptionalTimes/AxiomAudit.lean') -Raw
    foreach ($taskSource in $taskBeforeHashes) {
        if ($taskSource.path -eq 'lakefile.lean' -or $taskSource.path -eq 'ExceptionalTimes/AxiomAudit.lean') { continue }
        $taskModule = $taskSource.path.Replace('/', '.').Replace('.lean', '')
        if ($taskAuditText -notmatch ('(?m)^import ' + [regex]::Escape($taskModule) + '\s*$')) {
            throw "AxiomAudit does not import project module $taskModule."
        }
    }
    & $LakePath @taskLakeArgs --wfail build 2>&1 |
        Tee-Object -FilePath verification/full-build.log
    $taskBuildExit = $LASTEXITCODE
    if ($taskBuildExit -ne 0) { throw "Lean build failed: exit $taskBuildExit." }

    $taskLog = Get-Content -LiteralPath verification/full-build.log -Raw
    if ($taskLog -match '\bsorryAx\b') { throw 'An audited declaration uses sorryAx.' }

    $taskHashes = @(Get-TaskSourceHashes)
    if (($taskBeforeHashes | ConvertTo-Json -Compress) -ne ($taskHashes | ConvertTo-Json -Compress)) {
        throw 'Project sources changed during verification. Run again after all source edits finish.'
    }
    $taskReport = [ordered]@{
        checkedAtUtc = (Get-Date).ToUniversalTime().ToString('o')
        leanVersion = ($taskVersion -join "`n")
        mathlibCommit = 'd13f23b723b8a846827a245b89c10fc7d3f11612'
        buildExitCode = $taskBuildExit
        warningsAreErrors = $true
        full3136Theorem = 'PROVED CONDITIONALLY: PublishedNearestNeighborDimension.exists_realization_dimension; exact literature hypotheses in PublishedInputs.txt'
        sources = @($taskHashes)
    }
    $taskReport | ConvertTo-Json -Depth 6 |
        Set-Content -LiteralPath verification/status.json -Encoding UTF8
    Write-Output 'All project modules and the full conditional 31/36 theorem checked. Literature hypotheses and their source correspondence remain explicit.'
}
finally {
    Set-Location -LiteralPath $taskOldLocation.Path
}

