CONDITIONAL LEAN PROOF OF THE 31/36 THEOREM

Entry point
===========
ExceptionalTimes.PublishedNearestNeighborDimension.exists_realization_dimension
in ExceptionalTimes/PublishedNearestNeighborDimension.lean.

The statement constructs the actual rate-one nearest-neighbor exclusion
process on the infinite triangular lattice, with independent fair initial
site colors and independent Poisson clocks on unordered neighboring pairs.
With probability one, simultaneously for every 0<=a<b, the set of times
in (a,b) at which an infinite black cluster exists has Hausdorff dimension
31/36. In particular every such interval contains exceptional times.

Trust boundary
==============
This is a conditional proof. Its named literature inputs are explicit
hypotheses of the theorem, listed in PublishedInputs.txt. Lean verifies
the implication from those exact predicates to the conclusion. The
published papers and preprints have not all been formalized in Lean.
Several inputs are explicitly identified conventional consequences of
multiple source results; their source-to-predicate translations are
explained in the accompanying scope audits and remain outside Lean.
The OpenAI preprint inputs are pinned to a specific repository commit.

The new finite-word comparison is proved internally. The entry point
has no assumed canonical mixing, new energy bound, coefficient limit,
forest estimate, or WordForestCertificate.Data hypothesis.

Main proof chain
================
DyadicWordForestCertificate constructs the concrete geometric bounds and
fixed-degree sewing limits. WordForestCertificate and ActualProductTransfer
pass to the actual two-time semigroups, including the nonlinear clock
remainders and all update degrees. WordProductBridge converts the kernels
to actual event probabilities. QuadAnnulusTransfer and the dyadic mixing
and energy modules feed the concrete graphical-process dimension driver.
Local clock normalization and both matching phases are handled explicitly.

Verification
============
443 Lean source files; 8241 project declarations, including 6231 theorems.
Integrated check completed at 2026-10-12T14:54:46.9317736Z.
The complete warning-fatal build audits every project declaration and
permits only propext, Classical.choice and Quot.sound as axioms.
Published inputs remain explicit theorem parameters.
verification/status.json contains the toolchain, successful build result,
and SHA256 hash of every source; verification/full-build.log records the
combined build and exhaustive transitive axiom audit.

Reproduction
============
Lean 4.34.1, commit 5045d0056413266e57c625dcd7c365b10e377c52.
Mathlib commit d13f23b723b8a846827a245b89c10fc7d3f11612.
The portable Lean/Lake files pin these dependencies.
From the project directory, with the pinned toolchain installed:
  lake exe cache get
  lake --wfail build
On Windows, Verify.ps1 runs the complete check and records source hashes.
Its optional LakePath and PackageOverrides arguments allow reuse of a
local checkout of those exact pinned dependencies. Local override paths
are not part of the portable project manifest.

Reading the project
===================
Start with the entry point and PublishedInputs.txt. FinalBoundaryReview.txt
checks the final statement and its assumption boundary. Other *Scope.txt
files explain the precise source translations and normalization choices.
Historical checkpoint notes and older conditional driver modules are
retained as intermediate results; they do not describe the final status.


